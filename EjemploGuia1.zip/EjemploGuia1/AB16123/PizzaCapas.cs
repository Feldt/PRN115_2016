﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EjemploGuia1
{
    public abstract class PizzaCapas : Pizza
    {
        private Pizza _pizzaCapas;

        public PizzaCapas(Pizza pizza)
        {
            _pizzaCapas = pizza;
        }

        public virtual string Ingredientes
        {
            get
            {
                return _pizzaCapas.Ingredientes;
            }
        }

        public virtual float Precio
        {
            get
            {
                return _pizzaCapas.Precio;
            }
        }
    }
}


