﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EjemploGuia1
{
    public class PizzaPeperoni : PizzaCapas
    {
        public PizzaPeperoni(Pizza pizza) : base(pizza)
        {

        }

        public override string Ingredientes
        {
            get
            {
                return base.Ingredientes + "+ Peperoni";
            }
        }

        public override float Precio
        {
            get
            {
                return base.Precio + 3.75f;
            }
        }
    }
}




