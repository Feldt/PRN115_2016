﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EjemploGuia1
{
    public class PizzaSupema : PizzaCapas
    {
        public PizzaSupema(Pizza pizza) : base(pizza)
        {

        }

        public override string Ingredientes
        {
            get
            {
                return base.Ingredientes + " + Carne + Cebolla";
            }
        }

        public override float Precio
        {
            get
            {
                return base.Precio + 4f;
            }
        }
    }
}