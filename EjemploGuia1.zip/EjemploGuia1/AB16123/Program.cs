﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjemploGuia1
{
    class Program
    {
        static void Main(string[] args)
        {
            Pizza pizza = new PizzaClasica();
            mostrar(pizza);

            pizza = new PizzaPeperoni(pizza);
            mostrar(pizza);


            pizza = new PizzaClasica(); //reset
            pizza = new PizzaSupema(pizza);
            mostrar(pizza);
        }

        private static void mostrar(Pizza pizza)
        {
            Console.WriteLine("{0}  {1:c}  {2}",pizza.GetType().Name, pizza.Precio,pizza.Ingredientes);
        }
    }
}
