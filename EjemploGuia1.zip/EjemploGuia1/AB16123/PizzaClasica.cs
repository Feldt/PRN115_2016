﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EjemploGuia1
{
    public sealed class PizzaClasica : Pizza
    {
        public string Ingredientes
        {
            get
            {
                return "Ingredientes Clasicos : ";
            }
        }

        public float Precio
        {
            get
            {
                return 20;
            }
        }
    }
}