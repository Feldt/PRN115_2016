﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EjemploGuia1
{
    public interface Pizza
    {
        string Ingredientes
        {
            get;
        }

        float Precio
        {
            get;
        }
    }
}



